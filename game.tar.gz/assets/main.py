import pygame
import random
import math
import asyncio

score_update = {}
pygame.init()
screen = pygame.display.set_mode((700, 500)) 
pygame.display.set_caption("Best Game by Talin")

# Fallback structures for missing image assets on web
try:
    background = pygame.image.load('road.png')
    background = pygame.transform.scale(background, (700, 500))
except:
    background = pygame.Surface((700, 500))
    background.fill((50, 50, 50))

try:
    icon = pygame.image.load('game_icon.png')
    pygame.display.set_icon(icon)
except:
    pass

try:
    playerImg = pygame.image.load('player_sprite.png')
    playerImg = pygame.transform.scale(playerImg, (64, 64))
except:
    playerImg = pygame.Surface((64, 64))
    playerImg.fill((0, 255, 0))

playerX = 37
playerY = 38
playerX_change = 0
playerY_change = 0
ENEMY_SPEED_X = 4
ENEMY_SPEED_Y = 3

enemyImg = []
enemyX = []
enemyY = []
enemyX_change = []
enemyY_change = []
enemy_change_timer = []
num_of_enemies = 4

for i in range(num_of_enemies):
    try:
        enemyImg.append(pygame.image.load('ufo.png'))
    except:
        surf = pygame.Surface((64, 64))
        surf.fill((255, 0, 0))
        enemyImg.append(surf)
        
    enemyX.append(random.randint(0, 636))
    enemyY.append(random.randint(50, 400))
    enemyX_change.append(ENEMY_SPEED_X)
    enemyY_change.append(random.choice([-ENEMY_SPEED_Y, ENEMY_SPEED_Y]))
    enemy_change_timer.append(pygame.time.get_ticks() + random.uniform(1000, 3000))

font = pygame.font.Font(None, 32)
over_font = pygame.font.Font(None, 64)
score_value = 0

def player(x, y):
    screen.blit(playerImg, (x, y))
def enemy(x, y, i):
    screen.blit(enemyImg[i], (x, y))
def show_score(x, y):
    score = font.render("Score : " + str(score_value), True, (0, 0, 0))
    screen.blit(score, (x, y))
def game_over_text():
    over_text = over_font.render("GAME OVER", True, (255, 0, 0))
    restart_text = font.render("Tap Screen to Play Again", True, (255, 255, 255))
    screen.blit(over_text, (200, 200))
    screen.blit(restart_text, (220, 280))
def is_collision(enemyX, enemyY, playerX, playerY):
    distance = math.sqrt((enemyX - playerX)**2 + (enemyY - playerY)**2)
    return distance < 23

# Optimized Responsive Joystick Settings
JOYSTICK_CENTER = (110, 390)  # Positioned slightly higher for better thumb reach
JOYSTICK_RADIUS = 75         # Bigger target zone so your thumb doesn't slip off
KNOB_RADIUS = 30
MAX_SPEED = 7                # Boosted player response speed for snappy dodges
DEADZONE = 15                # Small center pocket so the ship stops completely when you let go

def draw_joystick(knob_pos):
    # Translucent styled glass circles
    pygame.draw.circle(screen, (255, 255, 255, 60), JOYSTICK_CENTER, JOYSTICK_RADIUS, 5)
    pygame.draw.circle(screen, (255, 255, 255, 140), knob_pos, KNOB_RADIUS)

async def main():
    global playerX, playerY, playerX_change, playerY_change, score_value
    
    clock = pygame.time.Clock()
    running = True
    game_over = False

    while running:
        screen.fill((0, 0, 0))
        screen.blit(background, (0, 0))
        
        knob_pos = list(JOYSTICK_CENTER)
        joy_x_out = 0
        joy_y_out = 0
        
        mouse_pos = pygame.mouse.get_pos()
        mouse_pressed = pygame.mouse.get_pressed()
        
        if mouse_pressed: 
            if game_over:
                game_over = False
                score_value = 0
                playerX, playerY = 37, 38
                for i in range(num_of_enemies):
                    enemyX[i] = random.randint(0, 636)
                    enemyY[i] = random.randint(50, 400)
            else:
                # Direct distance calculations
                dx = mouse_pos[0] - JOYSTICK_CENTER[0]
                dy = mouse_pos[1] - JOYSTICK_CENTER[1]
                distance = math.sqrt(dx**2 + dy**2)
                
                # Snappy Input Handler: Instantly checks thumb offset relative to center
                # Snappy Input Handler: Instantly checks thumb offset relative to center
                if distance < JOYSTICK_RADIUS + 60:
                    # Bound visual knob inside the control ring
                    if distance > JOYSTICK_RADIUS:
                        new_knob_x = int(JOYSTICK_CENTER[0] + (dx / distance) * JOYSTICK_RADIUS)
                        new_knob_y = int(JOYSTICK_CENTER[1] + (dy / distance) * JOYSTICK_RADIUS)
                        knob_pos = (new_knob_x, new_knob_y)
                    else:
                        knob_pos = mouse_pos
                    
                    # High-Speed Axis Processing: Instant full velocity outside deadzone
                    if abs(dx) > DEADZONE:
                        joy_x_out = MAX_SPEED if dx > 0 else -MAX_SPEED
                    if abs(dy) > DEADZONE:
                        joy_y_out = MAX_SPEED if dy > 0 else -MAX_SPEED

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            # Desktop Keyboard Support
            if event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_LEFT, pygame.K_a]: playerX_change = -MAX_SPEED
                if event.key in [pygame.K_RIGHT, pygame.K_d]: playerX_change = MAX_SPEED
                if event.key in [pygame.K_UP, pygame.K_w]: playerY_change = -MAX_SPEED
                if event.key in [pygame.K_DOWN, pygame.K_s]: playerY_change = MAX_SPEED
                if game_over and event.key == pygame.K_SPACE:
                    game_over = False
                    score_value = 0
                    playerX, playerY = 37, 38
                    for i in range(num_of_enemies):
                        enemyX[i] = random.randint(0, 636)
                        enemyY[i] = random.randint(50, 400)

            if event.type == pygame.KEYUP:
                if event.key in [pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d]: playerX_change = 0
                if event.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: playerY_change = 0

        if not game_over:
            # Combine current analog control value tracks alongside desktop velocity triggers
            final_move_x = playerX_change if playerX_change != 0 else joy_x_out
            final_move_y = playerY_change if playerY_change != 0 else joy_y_out

            playerX += final_move_x
            playerY += final_move_y
            playerX = max(0, min(playerX, 636))
            playerY = max(0, min(playerY, 436))
            
            current_time = pygame.time.get_ticks()
            for i in range(num_of_enemies):
                enemyX[i] += enemyX_change[i]
                enemyY[i] += enemyY_change[i]
                if enemyX[i] <= 0 or enemyX[i] >= 636:
                    enemyX_change[i] *= -1
                if enemyY[i] <= 0 or enemyY[i] >= 436:
                    enemyY_change[i] *= -1
                
                if current_time > enemy_change_timer[i]:
                    enemyY_change[i] *= random.choice([-1, 1])
                    enemy_change_timer[i] = current_time + random.uniform(1000, 3000)
                if is_collision(enemyX[i], enemyY[i], playerX, playerY):
                    game_over = True
                enemy(enemyX[i], enemyY[i], i)
                
            player(playerX, playerY)
            draw_joystick(knob_pos)
            show_score(10, 10)
            score_value += 1
        else:
            game_over_text()

        pygame.display.update()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())